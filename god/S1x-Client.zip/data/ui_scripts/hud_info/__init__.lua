if (game:issingleplayer()) then
	return
end

include("settings")
include("hud")